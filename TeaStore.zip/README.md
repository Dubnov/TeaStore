# README

1. Open CMD and run mongod to start up the mongo db server.
2. Open another cmd and cd into the project directory.
3. Run npm install
4. After that, run node server.js to start up the server
5. Go to Google Chrome and type http://localhost:8080/ 
6. Enjoy!

Made by Dor Dubnov, Chen Goren and Bar Meyuhas

